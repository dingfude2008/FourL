//
//  Item.m
//  BLECollection
//
//  Created by rfstar on 14-4-29.
//  Copyright (c) 2014年 rfstar. All rights reserved.
//

#import "Item.h"

@implementation Item

@end
