//
//  ModuleParatemCellTableViewCell.h
//  BLECollection
//
//  Created by rfstar on 14-4-22.
//  Copyright (c) 2014年 rfstar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ModuleParatemCellTableViewCell : UITableViewCell

@end
