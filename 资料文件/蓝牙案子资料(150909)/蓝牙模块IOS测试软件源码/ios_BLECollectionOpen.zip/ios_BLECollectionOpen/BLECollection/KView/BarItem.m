//
//  BarItem.m
//  BLECollection
//
//  Created by rfstar on 13-12-24.
//  Copyright (c) 2013年 rfstar. All rights reserved.
//

#import "BarItem.h"

@implementation BarItem

@end
