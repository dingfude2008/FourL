//
//  BarItem.h
//  BLECollection
//
//  Created by rfstar on 13-12-24.
//  Copyright (c) 2013年 rfstar. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BarItem : NSObject


@property (nonatomic,strong) NSString *imageNormal,*imagePressed;
@property (nonatomic,strong) NSString *name;

@end
