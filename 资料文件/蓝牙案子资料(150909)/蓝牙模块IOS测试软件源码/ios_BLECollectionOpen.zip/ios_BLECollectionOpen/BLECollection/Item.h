//
//  Item.h
//  BLECollection
//
//  Created by rfstar on 14-4-29.
//  Copyright (c) 2014年 rfstar. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Item : NSObject

@property(nonatomic , strong) NSString                        * text,* message;
@property(nonatomic , assign) NSInteger                       numberID;
@end
